<?php
require_once 'functions.php';
add();
?>

<?php include(HEADER_TEMPLATE); ?>

<h2>Novo Cliente</h2>

<form action="add.php" method="post" data-bs-validate class="needs-validation" novalidate>
    <!-- area de campos do form -->
    <hr />
    <div class="row">
        <div class="col-md-7 mb-3">
            <label for="name" class="form-label">Nome / Razão Social</label>
            <input type="text" class="form-control" id="name" name="customer[name]" required>
            <div class="invalid-feedback">
                Por favor, preencha o nome ou a razão social.
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <label for="cpf_cnpj" class="form-label">CNPJ / CPF</label>
            <input type="text" class="form-control" id="cpf_cnpj" name="customer[cpf_cnpj]" required>
            <div class="invalid-feedback">
                Por favor, preencha o CPF ou CNPJ.
            </div>
        </div>

        <div class="col-md-2 mb-3">
            <label for="birthdate" class="form-label">Data de Nascimento</label>
            <input type="date" class="form-control" id="birthdate" name="customer[birthdate]" required>
        </div>
    </div>

    <div class="row">
        <div class="col-md-5 mb-3">
            <label for="address" class="form-label">Endereço</label>
            <input type="text" class="form-control" id="address" name="customer[address]" required>
            <div id="validationServerAddressInvalid" class="invalid-feedback">Please enter a mailing address</div>

        </div>

        <div class="col-md-3 mb-3">
            <label for="hood" class="form-label">Bairro</label>
            <input type="text" class="form-control" id="hood" name="customer[hood]" required>
        </div>

        <div class="col-md-2 mb-3">
            <label for="zip_code" class="form-label">CEP</label>
            <input type="text" class="form-control" id="zip_code" name="customer[zip_code]" maxlength="9"
                placeholder="00000-000" required>
        </div>

        <div class="col-md-2 mb-3">
            <label for="created" class="form-label">Data de Cadastro</label>
            <input type="text" class="form-control" id="created" name="customer[created]" disabled>
        </div>
    </div>


    <div class="row">
        <div class="col-md-5 mb-3">
            <label for="city" class="form-label">Município</label>
            <input type="text" class="form-control" id="city" name="customer[city]" required>
        </div>

        <div class="col-md-2 mb-3">
            <label for="phone" class="form-label">Telefone</label>
            <input type="text" class="form-control" id="phone" maxlength="15" name="customer[phone]" required>
        </div>

        <div class="col-md-2 mb-3">
            <label for="mobile" class="form-label">Celular</label>
            <input type="text" class="form-control" id="mobile" maxlength="15" name="customer[mobile]" required>
        </div>

        <div class="col-md-1 mb-3">
            <label for="state" class="form-label">UF</label>
            <input type="text" class="form-control text-uppercase" id="state" name="customer[state]" maxlength="2"
                required>
        </div>

        <div class="col-md-2 mb-3">
            <label for="ie" class="form-label">Inscrição Estadual</label>
            <input type="text" class="form-control" id="ie" name="customer[ie]" required>
        </div>
    </div>

    <div id="actions" class="row mt-3">
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary">Salvar</button>
            <a href="index.php" class="btn btn-danger">Cancelar</a>
        </div>
    </div>
</form>

<script>
    // Example starter JavaScript for preventing form submissions when there are invalid fields
    (() => {
        'use strict'

        const forms = document.querySelectorAll('form[data-bs-validate]')

        for (const form of forms) {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                for (const control of form.elements) {
                    if (control.willValidate) {
                        control.setAttribute('aria-invalid', String(!control.validity.valid))
                    }
                }
            })

            // Clear aria-invalid as users correct individual fields
            form.addEventListener('input', event => {
                const control = event.target
                if (control.willValidate && control.hasAttribute('aria-invalid')) {
                    control.setAttribute('aria-invalid', String(!control.validity.valid))
                }
            })
        }
    })()
</script>

<?php include FOOTER_TEMPLATE; ?>