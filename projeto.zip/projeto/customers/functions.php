<?php

ob_start();
include('../config.php');
include(DBAPI);

$customers = null;
$customer = null;

/**
 *  Listagem de Clientes
 */
function index()
{
  global $customers;
  $customers = find_all('customers');
}

/**
 *  Visualização de um Cliente
 */
function view($id = null)
{
  global $customer;
  $customer = find('customers', $id);
}

/**
 * Formatar numero de telefone
 */
function formatPhone($phone)
{
  $phone = preg_replace('/\D/', '', $phone);

  if (strlen($phone) === 11) {
    return sprintf(
      '(%s) %s-%s',
      substr($phone, 0, 2),
      substr($phone, 2, 5),
      substr($phone, 7, 4)
    );
  }

  if (strlen($phone) === 10) {
    return sprintf(
      '(%s) %s-%s',
      substr($phone, 0, 2),
      substr($phone, 2, 4),
      substr($phone, 6, 4)
    );
  }

  return $phone;
}

/**
 * Formatar data
 * @param string $dado
 */
function formatarData($dado, $format = 'd/m/Y'): string
{
  $data = new DateTimeImmutable($dado);
  return $data->format($format);
}


/**
*  Insere um registro no BD
*/
function save($table = null, $data = null) {

  $database = open_database();

  $columns = null;
  $values = null;

  //print_r($data);

  foreach ($data as $key => $value) {
    $columns .= trim($key, "'") . ",";
    $values .= "'$value',";
  }

  // remove a ultima virgula
  $columns = rtrim($columns, ',');
  $values = rtrim($values, ',');
  
  $sql = "INSERT INTO " . $table . "($columns)" . " VALUES " . "($values);";

  try {
    $database->query($sql);

    $_SESSION['message'] = 'Registro cadastrado com sucesso.';
    $_SESSION['type'] = 'success';
  
  } catch (Exception $e) { 
  
    $_SESSION['message'] = 'Nao foi possivel realizar a operacao.';
    $_SESSION['type'] = 'danger';
  } 

  close_database($database);
}

/**
 *  Cadastro de Clientes
 */

function add()
{
  if (!empty($_POST['customer'])) {

    // $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
    $today = new DateTime('now', new DateTimeZone("-0300"));

    $customer = $_POST['customer'];
    $customer['modified'] = $customer['created'] = $today->format("Y-m-d H:i:s");

    save('customers', $customer);
    header('location: index.php');
  }
}


/**
 *	Atualizacao/Edicao de Cliente
 */
function edit()
{

  // $now = date_create('now', new DateTimeZone('America/Sao_Paulo'));
  $now = new DateTime('now', new DateTimeZone("-0300"));


  if (isset($_GET['id'])) {

    $id = $_GET['id'];

    if (isset($_POST['customer'])) {

      $customer = $_POST['customer'];
      $customer['modified'] = $now->format("Y-m-d H:i:s");

      update('customers', $id, $customer);
      header('location: index.php');
    } else {

      global $customer;
      $customer = find('customers', $id);
    }
  } else {
    header('location: index.php');
  }
}

/**
 *  Atualiza um registro em uma tabela, por ID
 */
function update($table = null, $id = 0, $data = null) {

  $database = open_database();

  $items = null;

  foreach ($data as $key => $value) {
    $items .= trim($key, "'") . "='$value',";
  }

  // remove a ultima virgula
  $items = rtrim($items, ",");

  // $sql  = "UPDATE " . $table;
  // $sql .= " SET $items";
  // $sql .= " WHERE id=" . $id . ";";

  $sql  = "UPDATE  $table SET $items  WHERE id=$id;";

  try {
    $database->query($sql);

    $_SESSION['message'] = 'Registro atualizado com sucesso.';
    $_SESSION['type'] = 'success';

  } catch (Exception $e) { 

    $_SESSION['message'] = 'Nao foi possivel realizar a operacao.';
    $_SESSION['type'] = 'danger';
  } 

  close_database($database);
}

/**
 *  Exclusão de um Cliente
 */
function delete($id = null) {

  global $customer;
  $customer = remove('customers', $id);

  header('location: index.php');
}