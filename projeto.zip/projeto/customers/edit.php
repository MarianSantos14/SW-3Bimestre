<?php
require_once 'functions.php';
edit();
?>

<?php include(HEADER_TEMPLATE); ?>

<h2>Novo Cliente</h2>

<form action="edit.php?id=<?php echo $customer['id']; ?>" method="post">
    <!-- area de campos do form -->
    <hr />
    <div class="row">
        <div class="col-md-7 mb-3">
            <label for="name" class="form-label">Nome / Razão Social</label>
            <input type="text" class="form-control" id="name" name="customer[name]" value="<?= $customer['name']; ?>">
        </div>

        <div class="col-md-3 mb-3">
            <label for="cpf_cnpj" class="form-label">CNPJ / CPF</label>
            <input type="text" class="form-control" id="cpf_cnpj" name="customer[cpf_cnpj]" value="<?= $customer['cpf_cnpj']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="birthdate" class="form-label">Data de Nascimento</label>
            <input type="text" class="form-control" id="birthdate" name="customer[birthdate]" value="<?= formatarData($customer['birthdate']) ?>">
        </div>
    </div>

    <div class="row">
        <div class="col-md-5 mb-3">
            <label for="address" class="form-label">Endereço</label>
            <input type="text" class="form-control" id="address" name="customer[address]" value="<?= $customer['address']; ?>">
        </div>

        <div class="col-md-3 mb-3">
            <label for="hood" class="form-label">Bairro</label>
            <input type="text" class="form-control" id="hood" name="customer[hood]" value="<?= $customer['hood']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="zip_code" class="form-label">CEP</label>
            <input type="text" class="form-control" id="zip_code" name="customer[zip_code]" maxlength="9"
                placeholder="00000-000" value="<?= $customer['zip_code']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="created" class="form-label">Data de Cadastro</label>
            <input type="text" class="form-control" id="created" name="customer[created]" disabled>
        </div>
    </div>


    <div class="row">
        <div class="col-md-5 mb-3">
            <label for="city" class="form-label">Município</label>
            <input type="text" class="form-control" id="city" name="customer[city]" value="<?= $customer['city']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="phone" class="form-label">Telefone</label>
            <input type="text" class="form-control" id="phone" name="customer[phone]" value="<?= $customer['phone']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="mobile" class="form-label">Celular</label>
            <input type="text" class="form-control" id="mobile" name="customer[mobile]" value="<?= $customer['mobile']; ?>">
        </div>

        <div class="col-md-1 mb-3">
            <label for="state" class="form-label">UF</label>
            <input type="text" class="form-control text-uppercase" id="state" name="customer[state]" maxlength="2" value="<?= $customer['state']; ?>">
        </div>

        <div class="col-md-2 mb-3">
            <label for="ie" class="form-label">Inscrição Estadual</label>
            <input type="text" class="form-control" id="ie" name="customer[ie]" value="<?= $customer['ie']; ?>">
        </div>
    </div>

    <div id="actions" class="row mt-3">
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary">Salvar</button>
            <a href="index.php" class="btn btn-default">Cancelar</a>
        </div>
    </div>
</form>

<?php include FOOTER_TEMPLATE; ?>